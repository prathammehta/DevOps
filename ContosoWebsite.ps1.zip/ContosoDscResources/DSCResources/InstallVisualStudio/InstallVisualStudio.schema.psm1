configuration InstallVisualStudio
{
	
}